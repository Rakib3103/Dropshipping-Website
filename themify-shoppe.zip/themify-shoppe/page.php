<?php 
global $themify;
$themify->isPage=true;
get_template_part('index');