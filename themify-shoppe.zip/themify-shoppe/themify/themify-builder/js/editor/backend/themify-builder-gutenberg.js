( wp=> {
	'use strict';

	const el = wp.element.createElement;

    let isInit=false;
	wp.blocks.registerBlockType( 'themify-builder/canvas', {
		title:  'Themify Builder',
		icon: 'layout',
		category: 'layout',
		useOnce: true,
        supports: {
            multiple:false,
            reusable: false,
            inserter: false,
            html: false,
			duplicate: false
        },
		attributes : {
			content: {
				source: 'raw'
			}
		},
		edit(props) {
			var content = props.attributes.content;
			function onChangeContent( newContent ) {
				props.setAttributes( { content: newContent } );
			}

			setTimeout(()=>{
                if (isInit===false){
                    isInit=true; 
                    document.getElementById('block-'+props.clientId).removeAttribute('tabIndex');
                    Themify.trigger('tb_canvas_loaded');
					Themify.on( 'themify_builder_save_data', function(data) {
						props.setAttributes( { content: data.static_content || '' } );
					} );
                }
			}, 800);

			return [
				el('div', { id: 'tb_canvas_block',className:'tf_rel', key: 'canvas'}, 'placeholder builder' ),
				el( 'textarea', {
					className: props.className + ' tf_hide',
					onChange: onChangeContent,
					value: content,
					key : 'static'
				} )
			];
		},
		save(props) {
			var content = props.attributes.content;
			/* save unescape HTML */
			return el( '', {
				dangerouslySetInnerHTML: {
					__html: content
				}
			} );
		}
	} );

} )(wp);